//
//  DiyiViewController.h
//  乐无极限
//
//  Created by lanou3g on 16/4/15.
//  Copyright © 2016年 陈林林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiyiViewController : UIViewController

@property(nonatomic,strong)UIView *view11111;

@end
