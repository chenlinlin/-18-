//
//  DierViewController.m
//  乐无极限
//
//  Created by lanou3g on 16/4/15.
//  Copyright © 2016年 陈林林. All rights reserved.
//

#import "DierViewController.h"

@interface DierViewController ()

@end

@implementation DierViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor =[UIColor yellowColor];
    [self data];
}

-(void)data{
    NSURLSession *session =[NSURLSession sharedSession];
    NSString *str1 =@"%2F";
    NSString *str2 =@"%2B";
    NSString *str3 =@"%2B";
    NSString *str4 =@"%2F";

    //创建url
    NSString *urlstring =[NSString stringWithFormat:@"http://c.3g.163.com/recommend/getSubDocPic?passport=&devId=REzDLjQEHT%@F9xKY%@TXpgveA5r1coZ%@LHpmSZJDW3hwkr2CbQE0yfilL2fv7V6nq&size=20&version=6.0&spever=false&net=wifi&lat=&lon=&ts=1460944792&sign=1aATVXBSFM7JpD9BY92fnT4mgwGfLuLvXwDgvDehDI148ErR02zJ6%@KXOnxX046I&encryption=1&canal=appstore",str1,str2,str3,str4];
   
    NSURL *url =[NSURL URLWithString:urlstring];
    //通过URL初始化task 在block内处理数据
    NSURLSessionTask *task =[session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        NSDictionary *dic =[NSJSONSerialization JSONObjectWithData:data options:(NSJSONReadingAllowFragments) error:nil];
        [dic writeToFile:@"/Users/lanou3g/Desktop/pppp/newsssbbb.plist" atomically:YES];
      
    }];
    
    [task resume];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
