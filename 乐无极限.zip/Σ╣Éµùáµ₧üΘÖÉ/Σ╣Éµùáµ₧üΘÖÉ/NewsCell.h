//
//  NewsCell.h
//  乐无极限
//
//  Created by lanou3g on 16/4/15.
//  Copyright © 2016年 陈林林. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsCell : UITableViewCell

@property(nonatomic,strong)UIImageView *imgView;

@property(nonatomic,strong)UILabel *titelLabel;

@property(nonatomic,strong)UILabel *neirongLabel;

@property(nonatomic,strong)UILabel *shijianLabel;
@end
