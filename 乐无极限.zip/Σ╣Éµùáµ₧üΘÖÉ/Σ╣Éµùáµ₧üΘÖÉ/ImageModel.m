//
//  ImageModel.m
//  乐无极限
//
//  Created by lanou3g on 16/4/17.
//  Copyright © 2016年 陈林林. All rights reserved.
//

#import "ImageModel.h"

@implementation ImageModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


@end
