//
//  Header.h
//  乐无极限
//
//  Created by lanou3g on 16/4/16.
//  Copyright © 2016年 陈林林. All rights reserved.
//

#ifndef Header_h
#define Header_h

#import <UIImageView+WebCache.h>
#import <MJRefresh.h>
#import <AFNetworking.h>
#import "NSObject+MJKeyValue.h"


#define Image [UIImage imageNamed:@"aa"]
#define ScreenWidth    [[UIScreen mainScreen] bounds].size.width
#define ScreenHeight   [[UIScreen mainScreen] bounds ].size.height

#endif /* Header_h */
