//
//  NSString+Html.h
//  PKTProject
//
//  Created by young on 15/6/2.
//  Copyright (c) 2015年 young. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Html)

+ (NSString *)importStyleWithHtmlString:(NSString *)HTML;
@end
